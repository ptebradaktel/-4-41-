﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISRPO_LR4
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            List<Клиент> клиенты = new List<Клиент>
        {
            new Клиент(1, "Иван", "Иванов", "ivan@example.com", "+79001234567"),
            new Клиент(2, "Мария", "Петрова", "maria@example.com", "+79007654321")
        };

            List<Тур> туры = new List<Тур>
        {
            new Тур(1, "Россия", "Москва", "Гостиница Москва", 5000),
            new Тур(2, "Испания", "Барселона", "Отель Барселона", 10000)
        };

            Бронирование бронирование = new Бронирование(1, 1, 2, DateTime.Now, 2);
            бронирование.ПоказатьИнформацию(клиенты, туры);
        }
    }
}
