
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Тур {

    public int Id { get; set; }
    public string Страна { get; set; }
    public string Город { get; set; }
    public string Отель { get; set; }
    public decimal Цена { get; set; }

    public Тур(int id, string страна, string город, string отель, decimal цена)
    {
        Id = id;
        Страна = страна;
        Город = город;
        Отель = отель;
        Цена = цена;
    }

    public void ПоказатьИнформацию()
    {
        Console.WriteLine($"Тур: {Город}, {Страна} - {Отель}, Цена: {Цена}");
    }

}