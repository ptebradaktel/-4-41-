
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Клиент {

    public int Id { get; set; }
    public string Имя { get; set; }
    public string Фамилия { get; set; }
    public string Email { get; set; }
    public string Телефон { get; set; }

    public Клиент(int id, string имя, string фамилия, string email, string телефон)
    {
        Id = id;
        Имя = имя;
        Фамилия = фамилия;
        Email = email;
        Телефон = телефон;
    }

    public void ПоказатьИнформацию()
    {
        Console.WriteLine($"Клиент: {Имя} {Фамилия}, Email: {Email}, Телефон: {Телефон}");
    }

}