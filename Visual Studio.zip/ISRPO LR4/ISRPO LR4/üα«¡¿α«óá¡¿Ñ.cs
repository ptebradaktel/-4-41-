
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Бронирование {

    public int Id { get; set; }
    public int Id_Клиента { get; set; }
    public int Id_Тура { get; set; }
    public DateTime ДатаБронирования { get; set; }
    public int Количество { get; set; }

    public Бронирование(int id, int id_Клиента, int id_Тура, DateTime датаБронирования, int количество)
    {
        Id = id;
        Id_Клиента = id_Клиента;
        Id_Тура = id_Тура;
        ДатаБронирования = датаБронирования;
        Количество = количество;
    }

    public void ПоказатьИнформацию(List<Клиент> клиенты, List<Тур> туры)
    {
        Клиент клиент = клиенты.Find(c => c.Id == Id_Клиента);
        Тур тур = туры.Find(t => t.Id == Id_Тура);
        if (клиент != null && тур != null)
        {
            Console.WriteLine($"Бронирование: {клиент.Имя} {клиент.Фамилия} на тур {тур.Город}, {тур.Страна} " +
                              $"на дату {ДатаБронирования.ToShortDateString()}, Количество: {Количество}");
        }
        else
        {
            Console.WriteLine("Не удалось найти информацию о клиенте или туре.");
        }
    }

}